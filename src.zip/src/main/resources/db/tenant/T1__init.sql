-- =====================================================================
-- Ikyam VendorNex — per-company (tenant) schema, T1
-- Run once for every onboarded company, with search_path set to
-- "<tenant schema>", ik_vendor. Table names are unqualified on purpose:
-- they are created in the tenant schema, while ik_onboarding_company / global_users
-- resolve to the ik_vendor schema.
--
-- This is the tenant part of V1__init.sql (everything except ik_onboarding_company,
-- company_settings and login_activity, which live in ik_vendor).
-- company_id columns are kept so existing queries run unchanged.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 3. vendors — App-owned; becomes / links to a B1 Business Partner (OCRD, CardType = S)
--    (declared before users because users.vendor_id references it)
-- ---------------------------------------------------------------------
CREATE TABLE ik_vendors (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    legal_name                  VARCHAR(200) NOT NULL,
    contact_name                VARCHAR(150),
    email                       VARCHAR(200),
    phone                       VARCHAR(40),
    link_type                   VARCHAR(10) NOT NULL DEFAULT 'NEW' CHECK (link_type IN ('NEW','EXISTING')),
    sap_card_code               VARCHAR(15),             -- OCRD.CardCode once created / linked
    sap_bp_status               VARCHAR(10) CHECK (sap_bp_status IN ('ACTIVE','INACTIVE')),
    vendor_group_code           INTEGER,                 -- OCRG.GroupCode (synced list)
    vendor_group_name           VARCHAR(100),
    street                      VARCHAR(200),
    city                        VARCHAR(100),
    state                       VARCHAR(100),
    zip_code                    VARCHAR(20),
    country                     VARCHAR(3),
    gstin                       VARCHAR(15),
    pan                         VARCHAR(10),
    bank_name                   VARCHAR(100),
    bank_account_no             VARCHAR(40),
    bank_ifsc                   VARCHAR(11),
    sap_bank_code               VARCHAR(30),             -- ODSC.BankCode — needed to push bank details to B1
    status                      VARCHAR(25) NOT NULL DEFAULT 'DRAFT'
                                CHECK (status IN ('DRAFT','PENDING_APPROVAL','SAP_SYNC_PENDING','SAP_SYNC_FAILED','ACTIVE','REJECTED','INACTIVE')),
    wizard_step                 SMALLINT NOT NULL DEFAULT 1,
    rejection_reason            VARCHAR(1000),
    created_by_user_id          UUID,
    invited_on                  DATE NOT NULL DEFAULT CURRENT_DATE,
    activated_at                TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_vendors_company_cardcode ON ik_vendors(company_id, sap_card_code) WHERE sap_card_code IS NOT NULL;
CREATE INDEX ix_vendors_company_status ON ik_vendors(company_id, status);

-- ---------------------------------------------------------------------
-- 4. users — App-owned. Consumes zero SAP B1 named-user licences.
-- ---------------------------------------------------------------------
CREATE TABLE ik_users (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID REFERENCES ik_onboarding_company(onboard_company_id),   -- NULL only for SUPER_ADMIN
    name                        VARCHAR(150) NOT NULL,
    email                       VARCHAR(200) NOT NULL,
    password_hash               VARCHAR(100),                     -- bcrypt; NULL until invite accepted
    role                        VARCHAR(20) NOT NULL
                                CHECK (role IN ('SUPER_ADMIN','ADMIN','APPROVER','REQUESTER','VENDOR')),
    status                      VARCHAR(20) NOT NULL DEFAULT 'INVITED'
                                CHECK (status IN ('INVITED','PENDING_APPROVAL','ACTIVE','REJECTED','DISABLED')),
    vendor_id                   UUID REFERENCES ik_vendors(id),      -- set when role = VENDOR
    department                  VARCHAR(100),                     -- requesters
    sap_employee_id             INTEGER,                          -- OHEM.empID, optional mapping for PR push
    invite_token                VARCHAR(80),
    invite_expires_at           TIMESTAMPTZ,
    rejection_reason            VARCHAR(1000),
    last_login_at               TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_users_company CHECK ((role = 'SUPER_ADMIN') = (company_id IS NULL)),
    CONSTRAINT ck_users_vendor  CHECK ((role = 'VENDOR') = (vendor_id IS NOT NULL))
);
CREATE UNIQUE INDEX ux_users_email ON ik_users(lower(email));
CREATE UNIQUE INDEX ux_users_invite ON ik_users(invite_token) WHERE invite_token IS NOT NULL;
CREATE INDEX ix_users_company_role ON ik_users(company_id, role);

-- ---------------------------------------------------------------------
-- 5. user_approval_stages — App-owned. Which approval stages an APPROVER may act on.
-- ---------------------------------------------------------------------
CREATE TABLE ik_user_approval_stages (
    user_id                     UUID NOT NULL REFERENCES ik_users(id) ON DELETE CASCADE,
    stage                       VARCHAR(20) NOT NULL CHECK (stage IN ('FINANCE','PROCUREMENT','COMPLIANCE')),
    PRIMARY KEY (user_id, stage)
);


-- Keeps ik_vendor.global_users (the table login/invite/activation read) identical to this table.
CREATE TRIGGER trg_users_sync_global AFTER INSERT OR UPDATE OR DELETE ON ik_users
    FOR EACH ROW EXECUTE FUNCTION ik_vendor.sync_user_to_global();

-- ---------------------------------------------------------------------
-- 7. doc_sequences — App-owned. Human-readable numbers for app documents.
-- ---------------------------------------------------------------------
CREATE TABLE ik_doc_sequences (
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    doc_type                    VARCHAR(10) NOT NULL CHECK (doc_type IN ('PR','RFQ','ASN')),
    prefix                      VARCHAR(20) NOT NULL,
    next_value                  INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (company_id, doc_type)
);

-- ---------------------------------------------------------------------
-- 8–13. SAP B1 master data — Synced (read). Refreshed by the master-sync job.
-- ---------------------------------------------------------------------
CREATE TABLE ik_sap_warehouses (                               -- OWHS
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    warehouse_code              VARCHAR(8) NOT NULL,
    warehouse_name              VARCHAR(100) NOT NULL,
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, warehouse_code)
);

CREATE TABLE ik_sap_items (                                    -- OITM (purchase items)
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    item_code                   VARCHAR(50) NOT NULL,
    item_name                   VARCHAR(200) NOT NULL,
    item_group_code             INTEGER,
    item_group_name             VARCHAR(100),
    purchase_uom                VARCHAR(20),
    inventory_uom               VARCHAR(20),
    avg_price                   NUMERIC(19,6),           -- OITM.AvgPrice (Service Layer: AvgStdPrice), baseline for price variance
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, item_code)
);
CREATE INDEX ix_sap_items_name ON ik_sap_items(company_id, lower(item_name));

CREATE TABLE ik_sap_item_stock (                               -- OITW
    company_id                  UUID NOT NULL,
    item_code                   VARCHAR(50) NOT NULL,
    warehouse_code              VARCHAR(8) NOT NULL,
    in_stock                    NUMERIC(19,6) NOT NULL DEFAULT 0,
    committed                   NUMERIC(19,6) NOT NULL DEFAULT 0,
    ordered                     NUMERIC(19,6) NOT NULL DEFAULT 0,
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, item_code, warehouse_code),
    FOREIGN KEY (company_id, item_code) REFERENCES ik_sap_items(company_id, item_code) ON DELETE CASCADE
);

CREATE TABLE ik_sap_vendor_groups (                            -- OCRG, Type = vendor
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    group_code                  INTEGER NOT NULL,
    group_name                  VARCHAR(100) NOT NULL,
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, group_code)
);

CREATE TABLE ik_sap_business_partners (                        -- OCRD, CardType = S
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    card_code                   VARCHAR(15) NOT NULL,
    card_name                   VARCHAR(200) NOT NULL,
    group_code                  INTEGER,
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,  -- Valid = tYES and Frozen = tNO
    federal_tax_id              VARCHAR(32),
    email                       VARCHAR(200),
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, card_code)
);

CREATE TABLE ik_sap_employees (                                -- OHEM (requester identity in B1_SYNC mode)
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    employee_id                 INTEGER NOT NULL,
    full_name                   VARCHAR(150) NOT NULL,
    department                  VARCHAR(100),
    email                       VARCHAR(200),
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, employee_id)
);

CREATE TABLE ik_sap_tax_codes (                                -- VatGroups (input) / OSTC
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id) ON DELETE CASCADE,
    tax_code                    VARCHAR(20) NOT NULL,
    tax_name                    VARCHAR(100),
    rate                        NUMERIC(9,4),
    last_synced_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (company_id, tax_code)
);

-- ---------------------------------------------------------------------
-- 14. vendor_documents — App-owned (onboarding uploads)
-- ---------------------------------------------------------------------
CREATE TABLE ik_vendor_documents (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    vendor_id                   UUID NOT NULL REFERENCES ik_vendors(id) ON DELETE CASCADE,
    doc_type                    VARCHAR(20) NOT NULL CHECK (doc_type IN ('GST','PAN','MSME','INSURANCE','CANCELLED_CHEQUE','OTHER')),
    file_name                   VARCHAR(255) NOT NULL,
    content_type                VARCHAR(100),
    size_bytes                  BIGINT NOT NULL,
    storage_key                 VARCHAR(300) NOT NULL,   -- path under the document store
    expiry_date                 DATE,
    uploaded_by_user_id         UUID REFERENCES ik_users(id),
    uploaded_at                 TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_vendor_documents_type ON ik_vendor_documents(vendor_id, doc_type) WHERE doc_type <> 'OTHER';

-- ---------------------------------------------------------------------
-- 15. approval_steps — App-owned. One row per (entity, stage) in the configured chain.
-- ---------------------------------------------------------------------
CREATE TABLE ik_approval_steps (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    entity_type                 VARCHAR(20) NOT NULL CHECK (entity_type IN ('VENDOR','REQUESTER','PURCHASE_REQUEST')),
    entity_id                   UUID NOT NULL,
    stage                       VARCHAR(20) NOT NULL CHECK (stage IN ('ADMIN','FINANCE','PROCUREMENT','COMPLIANCE')),
    seq                         SMALLINT NOT NULL,
    status                      VARCHAR(15) NOT NULL DEFAULT 'NOT_STARTED'
                                CHECK (status IN ('NOT_STARTED','PENDING','APPROVED','REJECTED','SKIPPED')),
    round                       SMALLINT NOT NULL DEFAULT 1,     -- increments on resubmission
    acted_by_user_id            UUID REFERENCES ik_users(id),
    acted_at                    TIMESTAMPTZ,
    remarks                     VARCHAR(1000),
    UNIQUE (entity_type, entity_id, round, stage)
);
CREATE INDEX ix_approval_queue ON ik_approval_steps(company_id, stage, status);

-- ---------------------------------------------------------------------
-- 16–17. purchase_requests / lines — App-owned (APP mode) or Mirrored (B1_SYNC, OPRQ/PRQ1)
-- ---------------------------------------------------------------------
CREATE TABLE ik_purchase_requests (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    pr_no                       VARCHAR(30) NOT NULL,
    source                      VARCHAR(5) NOT NULL CHECK (source IN ('APP','B1')),
    sap_doc_entry               INTEGER,
    sap_doc_num                 INTEGER,
    requester_user_id           UUID REFERENCES ik_users(id),
    requester_name              VARCHAR(150) NOT NULL,
    department                  VARCHAR(100),
    required_date               DATE,
    justification               VARCHAR(2000),
    status                      VARCHAR(20) NOT NULL DEFAULT 'PENDING_APPROVAL'
                                CHECK (status IN ('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','PARTIALLY_SOURCED','SOURCED','CLOSED','CANCELLED')),
    rejection_reason            VARCHAR(1000),
    sap_push_status             VARCHAR(15) NOT NULL DEFAULT 'NOT_REQUIRED'
                                CHECK (sap_push_status IN ('NOT_REQUIRED','QUEUED','POSTED','FAILED')),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, pr_no)
);
CREATE UNIQUE INDEX ux_pr_sap_entry ON ik_purchase_requests(company_id, sap_doc_entry) WHERE sap_doc_entry IS NOT NULL;
CREATE INDEX ix_pr_company_status ON ik_purchase_requests(company_id, status);

CREATE TABLE ik_purchase_request_lines (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    purchase_request_id         UUID NOT NULL REFERENCES ik_purchase_requests(id) ON DELETE CASCADE,
    line_num                    INTEGER NOT NULL,                 -- = PRQ1.LineNum when source = B1
    item_code                   VARCHAR(50) NOT NULL,
    item_name                   VARCHAR(200) NOT NULL,
    uom                         VARCHAR(20),
    quantity                    NUMERIC(19,6) NOT NULL CHECK (quantity > 0),
    sourced_qty                 NUMERIC(19,6) NOT NULL DEFAULT 0, -- moved into an RFQ or PO
    warehouse_code              VARCHAR(8),
    required_date               DATE,
    UNIQUE (purchase_request_id, line_num),
    CHECK (sourced_qty >= 0 AND sourced_qty <= quantity)
);

-- ---------------------------------------------------------------------
-- 18–23. RFQ, invitations, quotations, awards — App-owned (no B1 equivalent in the flow)
-- ---------------------------------------------------------------------
CREATE TABLE ik_rfqs (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    rfq_no                      VARCHAR(30) NOT NULL,
    title                       VARCHAR(200) NOT NULL,
    due_date                    DATE NOT NULL,
    status                      VARCHAR(20) NOT NULL DEFAULT 'OPEN'
                                CHECK (status IN ('OPEN','CLOSED','PARTIALLY_AWARDED','AWARDED','CANCELLED')),
    notes                       VARCHAR(2000),
    created_by_user_id          UUID REFERENCES ik_users(id),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, rfq_no)
);

CREATE TABLE ik_rfq_lines (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rfq_id                      UUID NOT NULL REFERENCES ik_rfqs(id) ON DELETE CASCADE,
    line_num                    INTEGER NOT NULL,
    item_code                   VARCHAR(50) NOT NULL,
    item_name                   VARCHAR(200) NOT NULL,
    uom                         VARCHAR(20),
    quantity                    NUMERIC(19,6) NOT NULL CHECK (quantity > 0),
    awarded_qty                 NUMERIC(19,6) NOT NULL DEFAULT 0,
    warehouse_code              VARCHAR(8),
    required_date               DATE,
    UNIQUE (rfq_id, line_num),
    CHECK (awarded_qty >= 0 AND awarded_qty <= quantity)
);

-- Which PR lines fed which RFQ line (PRs can be merged into one RFQ)
CREATE TABLE ik_rfq_line_sources (
    rfq_line_id                 UUID NOT NULL REFERENCES ik_rfq_lines(id) ON DELETE CASCADE,
    pr_line_id                  UUID NOT NULL REFERENCES ik_purchase_request_lines(id),
    quantity                    NUMERIC(19,6) NOT NULL,
    PRIMARY KEY (rfq_line_id, pr_line_id)
);

CREATE TABLE ik_rfq_vendors (
    rfq_id                      UUID NOT NULL REFERENCES ik_rfqs(id) ON DELETE CASCADE,
    vendor_id                   UUID NOT NULL REFERENCES ik_vendors(id),
    invited_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    viewed_at                   TIMESTAMPTZ,
    PRIMARY KEY (rfq_id, vendor_id)
);

CREATE TABLE ik_quotations (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rfq_id                      UUID NOT NULL REFERENCES ik_rfqs(id) ON DELETE CASCADE,
    vendor_id                   UUID NOT NULL REFERENCES ik_vendors(id),
    delivery_date               DATE NOT NULL,
    payment_terms               VARCHAR(200),
    notes                       VARCHAR(2000),
    revision                    SMALLINT NOT NULL DEFAULT 1,
    status                      VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED'
                                CHECK (status IN ('SUBMITTED','WITHDRAWN','AWARDED','PARTIALLY_AWARDED','NOT_AWARDED')),
    submitted_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (rfq_id, vendor_id)
);

CREATE TABLE ik_quotation_lines (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    quotation_id                UUID NOT NULL REFERENCES ik_quotations(id) ON DELETE CASCADE,
    rfq_line_id                 UUID NOT NULL REFERENCES ik_rfq_lines(id) ON DELETE CASCADE,
    unit_price                  NUMERIC(19,6) NOT NULL CHECK (unit_price >= 0),
    fulfil_qty                  NUMERIC(19,6) NOT NULL CHECK (fulfil_qty >= 0),
    tax_percent                 NUMERIC(9,4),
    UNIQUE (quotation_id, rfq_line_id)
);

-- Line-level award: an RFQ line can be split across vendors
CREATE TABLE ik_rfq_awards (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rfq_id                      UUID NOT NULL REFERENCES ik_rfqs(id) ON DELETE CASCADE,
    rfq_line_id                 UUID NOT NULL REFERENCES ik_rfq_lines(id) ON DELETE CASCADE,
    quotation_id                UUID NOT NULL REFERENCES ik_quotations(id),
    vendor_id                   UUID NOT NULL REFERENCES ik_vendors(id),
    awarded_qty                 NUMERIC(19,6) NOT NULL CHECK (awarded_qty > 0),
    unit_price                  NUMERIC(19,6) NOT NULL,
    purchase_order_id           UUID,                         -- FK added after purchase_orders
    awarded_by_user_id          UUID REFERENCES ik_users(id),
    awarded_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 24–25. purchase_orders / lines — Mirrored (OPOR/POR1). B1 DocNum is authoritative.
-- ---------------------------------------------------------------------
CREATE TABLE ik_purchase_orders (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    vendor_id                   UUID NOT NULL REFERENCES ik_vendors(id),
    card_code                   VARCHAR(15) NOT NULL,
    source                      VARCHAR(10) NOT NULL CHECK (source IN ('RFQ','PR','DIRECT','B1')),
    rfq_id                      UUID REFERENCES ik_rfqs(id),
    sap_doc_entry               INTEGER,
    sap_doc_num                 INTEGER,
    doc_date                    DATE NOT NULL DEFAULT CURRENT_DATE,
    doc_due_date                DATE NOT NULL,
    currency                    VARCHAR(3) NOT NULL DEFAULT 'INR',
    remarks                     VARCHAR(1000),
    doc_total                   NUMERIC(19,6) NOT NULL DEFAULT 0,
    status                      VARCHAR(25) NOT NULL DEFAULT 'SAP_PENDING'
                                CHECK (status IN ('SAP_PENDING','SAP_FAILED','PENDING_ACK','ACKNOWLEDGED','DECLINED',
                                                  'PARTIALLY_SHIPPED','SHIPPED','PARTIALLY_RECEIVED','COMPLETED','CANCELLED')),
    ack_remarks                 VARCHAR(1000),
    acknowledged_at             TIMESTAMPTZ,
    acknowledged_by_user_id     UUID REFERENCES ik_users(id),
    created_by_user_id          UUID REFERENCES ik_users(id),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_po_sap_entry ON ik_purchase_orders(company_id, sap_doc_entry) WHERE sap_doc_entry IS NOT NULL;
CREATE INDEX ix_po_company_vendor ON ik_purchase_orders(company_id, vendor_id, status);
ALTER TABLE ik_rfq_awards ADD CONSTRAINT fk_rfq_awards_po FOREIGN KEY (purchase_order_id) REFERENCES ik_purchase_orders(id);

CREATE TABLE ik_purchase_order_lines (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    purchase_order_id           UUID NOT NULL REFERENCES ik_purchase_orders(id) ON DELETE CASCADE,
    line_num                    INTEGER NOT NULL,                 -- = POR1.LineNum
    item_code                   VARCHAR(50) NOT NULL,
    item_name                   VARCHAR(200) NOT NULL,
    uom                         VARCHAR(20),
    quantity                    NUMERIC(19,6) NOT NULL CHECK (quantity > 0),
    unit_price                  NUMERIC(19,6) NOT NULL CHECK (unit_price >= 0),
    warehouse_code              VARCHAR(8) NOT NULL,
    tax_code                    VARCHAR(20),
    ship_date                   DATE,                             -- line delivery date (POR1.ShipDate)
    shipped_qty                 NUMERIC(19,6) NOT NULL DEFAULT 0, -- sum of ASN lines
    received_qty                NUMERIC(19,6) NOT NULL DEFAULT 0, -- sum of posted GRPO lines
    base_pr_line_id             UUID REFERENCES ik_purchase_request_lines(id),
    UNIQUE (purchase_order_id, line_num),
    CHECK (shipped_qty >= 0 AND received_qty >= 0)
);

-- ---------------------------------------------------------------------
-- 26–29. ASN and GRPO — App-owned workflow; GRPO posts to B1 (Drafts → OPDN)
-- ---------------------------------------------------------------------
CREATE TABLE ik_asns (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    purchase_order_id           UUID NOT NULL REFERENCES ik_purchase_orders(id),
    asn_no                      VARCHAR(30) NOT NULL,
    ship_date                   DATE NOT NULL,
    expected_delivery           DATE NOT NULL,
    carrier                     VARCHAR(100) NOT NULL,
    tracking_no                 VARCHAR(100) NOT NULL,
    vendor_invoice_no           VARCHAR(50),
    cartons                     INTEGER,
    pallets                     INTEGER,
    total_weight                VARCHAR(40),
    status                      VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED'
                                CHECK (status IN ('SUBMITTED','GRPO_DRAFTED','RECEIVED','CANCELLED')),
    submitted_by_user_id        UUID REFERENCES ik_users(id),
    submitted_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, asn_no)
);

CREATE TABLE ik_asn_lines (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asn_id                      UUID NOT NULL REFERENCES ik_asns(id) ON DELETE CASCADE,
    po_line_id                  UUID NOT NULL REFERENCES ik_purchase_order_lines(id),
    shipped_qty                 NUMERIC(19,6) NOT NULL CHECK (shipped_qty > 0),
    batch_no                    VARCHAR(50),
    UNIQUE (asn_id, po_line_id)
);

CREATE TABLE ik_grpos (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    asn_id                      UUID NOT NULL UNIQUE REFERENCES ik_asns(id),
    purchase_order_id           UUID NOT NULL REFERENCES ik_purchase_orders(id),
    sap_draft_entry             INTEGER,                         -- ODRF.DocEntry
    sap_doc_entry               INTEGER,                         -- OPDN.DocEntry once posted
    sap_doc_num                 INTEGER,
    status                      VARCHAR(20) NOT NULL DEFAULT 'DRAFT_PENDING'
                                CHECK (status IN ('DRAFT_PENDING','DRAFT_CREATED','DRAFT_FAILED','POSTING','POSTED','POST_FAILED')),
    posting_date                DATE,
    confirmed_by_user_id        UUID REFERENCES ik_users(id),
    confirmed_at                TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ik_grpo_lines (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    grpo_id                     UUID NOT NULL REFERENCES ik_grpos(id) ON DELETE CASCADE,
    po_line_id                  UUID NOT NULL REFERENCES ik_purchase_order_lines(id),
    asn_qty                     NUMERIC(19,6) NOT NULL,
    received_qty                NUMERIC(19,6) NOT NULL CHECK (received_qty >= 0),
    rejected_qty                NUMERIC(19,6) NOT NULL DEFAULT 0 CHECK (rejected_qty >= 0),
    warehouse_code              VARCHAR(8) NOT NULL,
    UNIQUE (grpo_id, po_line_id)
);

-- ---------------------------------------------------------------------
-- 30. vendor_score_snapshots — Derived. Monthly roll-up for the scorecard trend.
-- ---------------------------------------------------------------------
CREATE TABLE ik_vendor_score_snapshots (
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    vendor_id                   UUID NOT NULL REFERENCES ik_vendors(id) ON DELETE CASCADE,
    period                      DATE NOT NULL,                  -- first day of month
    otif_pct                    NUMERIC(5,2),
    quality_pct                 NUMERIC(5,2),
    price_variance_pct          NUMERIC(7,2),
    po_count                    INTEGER NOT NULL DEFAULT 0,
    computed_at                 TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vendor_id, period)
);

-- ---------------------------------------------------------------------
-- 31. sync_runs — App-owned (log). One row per master-data pull.
-- ---------------------------------------------------------------------
CREATE TABLE ik_sync_runs (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    entity                      VARCHAR(30) NOT NULL,   -- ITEMS / WAREHOUSES / VENDOR_GROUPS / BUSINESS_PARTNERS / EMPLOYEES / TAX_CODES / PURCHASE_REQUESTS / PURCHASE_ORDERS
    trigger_type                VARCHAR(10) NOT NULL CHECK (trigger_type IN ('SCHEDULED','MANUAL','LOGIN')),
    status                      VARCHAR(10) NOT NULL CHECK (status IN ('RUNNING','SUCCESS','FAILED')),
    records                     INTEGER NOT NULL DEFAULT 0,
    error_detail                TEXT,
    started_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at                 TIMESTAMPTZ
);
CREATE INDEX ix_sync_runs_company ON ik_sync_runs(company_id, started_at DESC);

-- ---------------------------------------------------------------------
-- 32. sync_transactions — App-owned (outbox). One row per Service Layer write.
--     Worker claims rows with FOR UPDATE SKIP LOCKED (safe under pgbouncer
--     transaction pooling and with several backend instances).
-- ---------------------------------------------------------------------
CREATE TABLE ik_sync_transactions (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL REFERENCES ik_onboarding_company(onboard_company_id),
    operation                   VARCHAR(30) NOT NULL
                                CHECK (operation IN ('CREATE_VENDOR','CREATE_PURCHASE_REQUEST','CREATE_PURCHASE_ORDER','CREATE_GRPO_DRAFT','POST_GRPO')),
    source_type                 VARCHAR(30) NOT NULL,   -- VENDOR / PURCHASE_REQUEST / PURCHASE_ORDER / GRPO
    source_id                   UUID NOT NULL,
    target_b1_object            VARCHAR(60) NOT NULL,   -- BusinessPartners, PurchaseOrders, Drafts, PurchaseDeliveryNotes …
    payload_snapshot            JSONB,                  -- exact request body sent (enables audit + retry)
    response_snapshot           JSONB,
    status                      VARCHAR(10) NOT NULL DEFAULT 'QUEUED'
                                CHECK (status IN ('QUEUED','RUNNING','POSTED','FAILED')),
    attempts                    INTEGER NOT NULL DEFAULT 0,
    max_attempts                INTEGER NOT NULL DEFAULT 5,
    next_attempt_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    sap_doc_entry               INTEGER,
    sap_key                     VARCHAR(50),            -- CardCode / DocNum returned by B1
    error_detail                TEXT,
    requested_by_user_id        UUID REFERENCES ik_users(id),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at                 TIMESTAMPTZ
);
CREATE INDEX ix_sync_tx_pick ON ik_sync_transactions(status, next_attempt_at) WHERE status = 'QUEUED';
CREATE INDEX ix_sync_tx_source ON ik_sync_transactions(source_type, source_id);

-- ---------------------------------------------------------------------
-- 33. ik_sap_connection — App-owned. SAP B1 company DBs chosen during onboarding
--     (several per tenant); users pick one in the DB-selector at login.
--     created_by / updated_by point at ik_vendor.global_users so SUPER_ADMIN
--     (who onboards the company and is not in this schema's users) is valid too.
-- ---------------------------------------------------------------------
CREATE TABLE ik_sap_connection (
    connection_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schema_id                   VARCHAR(25) NOT NULL REFERENCES ik_onboarding_company(schema_id),
    connection_name             VARCHAR(100) NOT NULL,      -- display / alias of the SAP company DB
    company_db_code             VARCHAR(100) NOT NULL,      -- B1 CompanyDB used for Service Layer login
    base_url                    VARCHAR(255) NOT NULL,      -- Service Layer base URL
    sap_username                VARCHAR(100) NOT NULL,
    sap_password                VARCHAR(255) NOT NULL,      -- AES-256-GCM, never plaintext
    is_default                  BOOLEAN NOT NULL DEFAULT FALSE,   -- pre-selected on the login screen
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,    -- users can select / post to it
    sequence_no                 INTEGER,                    -- order in the DB-selector dropdown
    last_health_check_at        TIMESTAMPTZ,
    last_health_status          VARCHAR(15),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by                  UUID NOT NULL REFERENCES ik_vendor.ik_global_users(id),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by                  UUID NOT NULL REFERENCES ik_vendor.ik_global_users(id),
    UNIQUE (schema_id, company_db_code)
);
-- at most one default connection per tenant
CREATE UNIQUE INDEX ux_ik_sap_connection_default ON ik_sap_connection(schema_id) WHERE is_default;

-- ---------------------------------------------------------------------
-- 34. ik_country / ik_state / ik_branch — App-owned masters, each row tied to the
--     SAP B1 company DB (ik_sap_connection) it belongs to / was posted to.
-- ---------------------------------------------------------------------
CREATE TABLE ik_country (
    country_code                VARCHAR(50) PRIMARY KEY,
    country_name                VARCHAR(200) NOT NULL,
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    schema_id                   VARCHAR(25) NOT NULL REFERENCES ik_onboarding_company(schema_id),
    connection_id               UUID NOT NULL REFERENCES ik_sap_connection(connection_id)
);

CREATE TABLE ik_state (
    state_code                  VARCHAR(50) PRIMARY KEY,
    state_name                  VARCHAR(200) NOT NULL,
    country_code                VARCHAR(50) NOT NULL REFERENCES ik_country(country_code),
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    schema_id                   VARCHAR(25) NOT NULL REFERENCES ik_onboarding_company(schema_id),
    connection_id               UUID NOT NULL REFERENCES ik_sap_connection(connection_id)
);
CREATE INDEX ix_ik_state_country ON ik_state(country_code);

CREATE TABLE ik_branch (
    branch_id                   VARCHAR(25) PRIMARY KEY,
    branch_name                 VARCHAR(255) NOT NULL,
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by                  UUID NOT NULL REFERENCES ik_vendor.ik_global_users(id),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by                  UUID NOT NULL REFERENCES ik_vendor.ik_global_users(id),
    schema_id                   VARCHAR(25) NOT NULL REFERENCES ik_onboarding_company(schema_id),
    connection_id               UUID REFERENCES ik_sap_connection(connection_id)   -- sheet lists no constraint; Added for multi-SAP-DB support
);
CREATE INDEX ix_ik_branch_connection ON ik_branch(connection_id);

-- ---------------------------------------------------------------------
-- 35. ik_success / ik_error — App-owned integration logs. One row per integration run:
--     type = Branch / Bank / Business Partner / GL Accounts / Incoming Payment /
--     Outgoing Payment / ITR / IT. json keeps the payload.
-- ---------------------------------------------------------------------
CREATE TABLE ik_success (
    success_id                  VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid()::text,
    schema_id                   VARCHAR(255) NOT NULL REFERENCES ik_onboarding_company(schema_id),
    executed_at                 DATE NOT NULL DEFAULT CURRENT_DATE,
    type                        VARCHAR(250) NOT NULL,
    last_sync_at                DATE NOT NULL DEFAULT CURRENT_DATE,
    success_desc                TEXT,
    json                        TEXT,                     -- payload
    created_by                  UUID NOT NULL REFERENCES ik_vendor.ik_global_users(id)
);
CREATE INDEX ix_ik_success_type ON ik_success(type, executed_at DESC);

CREATE TABLE ik_error (
    error_id                    VARCHAR(255) PRIMARY KEY DEFAULT gen_random_uuid()::text,
    schema_id                   VARCHAR(255) NOT NULL REFERENCES ik_onboarding_company(schema_id),
    executed_at                 DATE NOT NULL DEFAULT CURRENT_DATE,
    type                        VARCHAR(250) NOT NULL,
    error_desc                  TEXT NOT NULL,
    success_desc                TEXT,
    json                        TEXT,                     -- payload
    created_by                  UUID NOT NULL REFERENCES ik_vendor.ik_global_users(id)
);
CREATE INDEX ix_ik_error_type ON ik_error(type, executed_at DESC);

-- Issued session tokens for this company's users (hash only, never the raw JWT).
-- SUPER_ADMIN tokens live in ik_vendor.jwt_tokens instead.
CREATE TABLE ik_jwt_tokens (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id                     UUID NOT NULL REFERENCES ik_users(id) ON DELETE CASCADE,
    role                        VARCHAR(20),
    token_hash                  VARCHAR(64) NOT NULL,
    issued_at                   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at                  TIMESTAMPTZ
);
CREATE INDEX ix_jwt_tokens_user ON ik_jwt_tokens(user_id);
